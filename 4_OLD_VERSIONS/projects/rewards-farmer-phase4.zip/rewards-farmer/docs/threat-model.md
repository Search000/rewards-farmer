# Threat Model (Phase 3)

## Assets
Account passwords + TOTP secrets (`.env`), session cookies (`engine/sessions`), API token, webhook tokens (Telegram bot token, Discord URL), account emails, logs, `config.json`.

## Trust boundaries
Renderer (untrusted) | Main (trusted) | API child on loopback (semi-trusted, upstream code) | Bot child + browser visiting Microsoft/Bing pages (untrusted content) | Network.

## Threats and mitigations
| # | Threat | Mitigation | Residual |
|---|---|---|---|
| T1 | Other local user/process calls API | bind 127.0.0.1, random port, random token per launch, token in env not argv, constant-time compare (upstream) | same-user malware can read process env. out of scope, say so |
| T2 | Website in user's browser hits `localhost` API (CSRF / DNS rebinding) | token required on every endpoint, CORS not `*`, random port | token theft = no mitigation |
| T3 | Log content from remote pages injects script into UI | render logs as text only, strict CSP, no `innerHTML` | low |
| T4 | Secrets leak in logs/reports/screenshots/Git | main-process redaction (passwords, tokens, keys, cookies, `Authorization`, bot token patterns), grep test in CI, `.gitignore` for `.env`, `sessions/`, `logs/`, builds | new secret formats may slip. regex review each phase |
| T5 | Renderer compromise -> read `.env` | renderer never receives secrets; no fs/shell access; narrow IPC; password entered once, sent to main, cleared | low |
| T6 | `.env` / config corruption or loss | backup before every write (timestamped), atomic write (temp + rename), confirm destructive actions | backup copy holds passwords. restrict folder ACL, tell user |
| T7 | Malicious/broken upstream update | pinned commit, Phase 11 diff review + approval + tests + rollback, `npm ci` with lockfile, no auto-update | npm supply chain risk remains |
| T8 | Orphan engine/browser processes after crash | PID file, taskkill tree on exit, startup orphan check | low |
| T9 | Config write enabled widens API | flag on only for private token-protected instance; `reveal`, env override, schedule write stay off | accepted |
| T10 | Path traversal / arbitrary file via account path or diagnostics route | validate chosen paths (must be a file named `.env`-like, user-selected via OS dialog), app never builds paths from renderer strings | low |
| T11 | Electron misconfig (nodeIntegration, navigation, openExternal) | settings in architecture §8, allow-listed external URLs, update Electron on schedule | low |
| T12 | Account restriction/ban | not technical-mitigable. About page notice. no evasion built | user risk, stated openly |
| T13 | Webhook token exposed in `config.json` plaintext (upstream behavior) | mask in UI, redact in logs, warn user. `GET /config` redacted by default | stays plaintext on disk |
| T14 | License violation on redistribution | ship GPL text, notices, source offer | lawyer check |

## Out of scope
Defending against admin-level or same-user malware, Microsoft-side detection, network attackers on LAN (API loopback only).
