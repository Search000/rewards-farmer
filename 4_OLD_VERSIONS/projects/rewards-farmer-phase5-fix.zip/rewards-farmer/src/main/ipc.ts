import { app, ipcMain } from 'electron'
import { APP_NAME } from '../shared/app-info'
import type { AppInfo } from '../shared/app-info'
import { IPC } from '../shared/ipc-types'

export function registerIpc(): void {
    ipcMain.handle(IPC.appGetInfo, (): AppInfo => ({
        name: APP_NAME,
        version: app.getVersion(),
        platform: process.platform,
        electron: process.versions.electron,
        chrome: process.versions.chrome
    }))
}
