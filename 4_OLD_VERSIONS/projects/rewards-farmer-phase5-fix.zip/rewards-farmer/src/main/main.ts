import { app, BrowserWindow } from 'electron'
import { APP_NAME } from '../shared/app-info'
import { registerIpc } from './ipc'
import { createMainWindow } from './window'

app.setName(APP_NAME)

// Single instance lock (docs/architecture.md section 4, step 1).
if (!app.requestSingleInstanceLock()) {
    app.quit()
} else {
    let main: BrowserWindow | null = null

    app.on('second-instance', () => {
        if (main === null) return
        if (main.isMinimized()) main.restore()
        main.focus()
    })

    void app.whenReady().then(() => {
        registerIpc()
        main = createMainWindow()
        app.on('activate', () => {
            if (BrowserWindow.getAllWindows().length === 0) main = createMainWindow()
        })
    })

    app.on('window-all-closed', () => app.quit())
}
