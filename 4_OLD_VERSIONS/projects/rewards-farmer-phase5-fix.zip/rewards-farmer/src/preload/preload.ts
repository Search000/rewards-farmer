import { contextBridge, ipcRenderer } from 'electron'
import { IPC } from '../shared/ipc-types'
import type { AppInfo } from '../shared/app-info'
import type { FarmerShellApi } from '../shared/ipc-types'

const api: FarmerShellApi = {
    getAppInfo: () => ipcRenderer.invoke(IPC.appGetInfo) as Promise<AppInfo>
}

contextBridge.exposeInMainWorld('farmerShell', api)
