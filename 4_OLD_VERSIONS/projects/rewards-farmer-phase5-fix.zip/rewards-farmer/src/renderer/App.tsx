import CssBaseline from '@mui/material/CssBaseline'
import { ThemeProvider } from '@mui/material/styles'
import { useMemo, useState } from 'react'
import { AppShell } from './components/AppShell'
import { NotificationProvider } from './components/Notifications'
import { useHashRoute } from './hooks/useHashRoute'
import { DesignSystemPage } from './pages/DesignSystemPage'
import { PlaceholderPage } from './pages/PlaceholderPage'
import { buildTheme } from './theme'
import type { ThemeMode } from './tokens'

export function App() {
    const [route, navigate] = useHashRoute()
    // In-memory only in Phase 5. Persistence belongs to the main-process AppSettings (docs/architecture.md section 3).
    const [mode, setMode] = useState<ThemeMode>('dark')
    const theme = useMemo(() => buildTheme(mode), [mode])

    return (
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <NotificationProvider>
                <AppShell
                    route={route}
                    mode={mode}
                    onNavigate={navigate}
                    onToggleTheme={() => setMode((m) => (m === 'dark' ? 'light' : 'dark'))}
                >
                    {route === 'design-system' ? <DesignSystemPage /> : <PlaceholderPage route={route} />}
                </AppShell>
            </NotificationProvider>
        </ThemeProvider>
    )
}
