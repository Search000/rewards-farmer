export type RouteId =
    'home' | 'accounts' | 'parallel' | 'telegram' | 'discord' | 'settings' | 'about' | 'design-system'

export interface RouteDef {
    readonly id: RouteId
    readonly label: string
    readonly inSidebar: boolean
    // Phase that implements the real page; null = no reference screenshot, scope not decided.
    readonly implementedInPhase: number | null
}

// Sidebar order and labels come from screenshot 1 (7 items). 'design-system' is a development-only page.
export const ROUTES: readonly RouteDef[] = [
    { id: 'home', label: 'Home', inSidebar: true, implementedInPhase: 6 },
    { id: 'accounts', label: 'Accounts', inSidebar: true, implementedInPhase: 7 },
    { id: 'parallel', label: 'Parallel farming', inSidebar: true, implementedInPhase: null },
    { id: 'telegram', label: 'Telegram', inSidebar: true, implementedInPhase: null },
    { id: 'discord', label: 'Discord', inSidebar: true, implementedInPhase: null },
    { id: 'settings', label: 'Settings', inSidebar: true, implementedInPhase: 8 },
    { id: 'about', label: 'About', inSidebar: true, implementedInPhase: null },
    { id: 'design-system', label: 'Design system', inSidebar: false, implementedInPhase: null }
]

export const DEFAULT_ROUTE: RouteId = 'home'

export function parseRoute(hash: string): RouteId {
    const id = hash.replace(/^#\/?/, '')
    const found = ROUTES.find((r) => r.id === id)
    return found ? found.id : DEFAULT_ROUTE
}

export function routeHash(id: RouteId): string {
    return `#/${id}`
}
