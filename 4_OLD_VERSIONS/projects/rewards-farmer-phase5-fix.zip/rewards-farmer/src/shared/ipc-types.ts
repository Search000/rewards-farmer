import type { AppInfo } from './app-info'

// Every IPC channel is named here. No generic "invoke anything" passthrough (docs/architecture.md section 8).
export const IPC = {
    appGetInfo: 'app:get-info'
} as const

export interface IpcInvokeMap {
    [IPC.appGetInfo]: { args: []; result: AppInfo }
}

export interface FarmerShellApi {
    getAppInfo(): Promise<AppInfo>
}

declare global {
    interface Window {
        // Present only when the page runs inside the Electron window (preload exposes it).
        farmerShell?: FarmerShellApi
    }
}
