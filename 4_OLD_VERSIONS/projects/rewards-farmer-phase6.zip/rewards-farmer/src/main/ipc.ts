import { app, ipcMain } from 'electron'
import type { BrowserWindow, IpcMainInvokeEvent } from 'electron'
import { APP_NAME } from '../shared/app-info'
import type { AppInfo } from '../shared/app-info'
import { isValidTime } from '../shared/farmer-types'
import type { ActionResult, PersistedSettings } from '../shared/farmer-types'
import { IPC } from '../shared/ipc-types'
import type { PickResult } from '../shared/ipc-types'
import type { AppSettingsStore } from './appSettings'
import type { FarmerService } from './farmer'

interface IpcDeps {
    readonly farmer: FarmerService
    readonly settings: AppSettingsStore
    readonly getWindow: () => BrowserWindow | null
}

const bad = (message: string): ActionResult => ({ ok: false, code: 'BAD_REQUEST', message })

// Only the app's own window may call us (threat model T5, T11).
function trusted(event: IpcMainInvokeEvent, deps: IpcDeps): boolean {
    const win = deps.getWindow()
    return win !== null && !win.isDestroyed() && event.sender === win.webContents
}

export function registerIpc(deps: IpcDeps): void {
    const guard =
        <A extends unknown[], R>(fallback: R, fn: (...args: A) => Promise<R> | R) =>
        async (event: IpcMainInvokeEvent, ...args: A): Promise<R> =>
            trusted(event, deps) ? fn(...args) : fallback

    ipcMain.handle(
        IPC.appGetInfo,
        guard<[], AppInfo>(
            { name: APP_NAME, version: '', platform: '', electron: '', chrome: '', isPackaged: false },
            () => ({
                name: APP_NAME,
                version: app.getVersion(),
                platform: process.platform,
                electron: process.versions.electron,
                chrome: process.versions.chrome,
                isPackaged: app.isPackaged
            })
        )
    )
    ipcMain.handle(IPC.farmerGetState, (event: IpcMainInvokeEvent) => {
        if (!trusted(event, deps)) throw new Error('Untrusted sender.')
        return deps.farmer.getState()
    })
    ipcMain.handle(
        IPC.farmerPickAccountsFile,
        guard<[], PickResult>({ cancelled: false, result: bad('Untrusted sender.') }, () =>
            deps.farmer.pickAccounts()
        )
    )
    ipcMain.handle(
        IPC.farmerStart,
        guard<[], ActionResult>(bad('Untrusted sender.'), () => deps.farmer.startRun('user'))
    )
    ipcMain.handle(
        IPC.farmerStop,
        guard<[], ActionResult>(bad('Untrusted sender.'), () => deps.farmer.stopRun())
    )
    ipcMain.handle(
        IPC.farmerCreateConfig,
        guard<[], ActionResult>(bad('Untrusted sender.'), () => deps.farmer.createConfig())
    )
    ipcMain.handle(
        IPC.farmerRestartEngine,
        guard<[], ActionResult>(bad('Untrusted sender.'), () => deps.farmer.restartEngine())
    )
    ipcMain.handle(
        IPC.farmerSetTimer,
        guard<[unknown, unknown], ActionResult>(bad('Untrusted sender.'), (enabled, time) => {
            // Input validated in main (docs/architecture.md section 8).
            if (typeof enabled !== 'boolean' || typeof time !== 'string' || !isValidTime(time))
                return bad('Invalid timer values.')
            return deps.farmer.setTimer(enabled, time)
        })
    )
    ipcMain.handle(
        IPC.settingsGet,
        guard<[], PersistedSettings>(deps.settings.value, () => deps.settings.value)
    )
    ipcMain.handle(
        IPC.settingsSetTheme,
        guard<[unknown], void>(undefined, async (mode) => {
            if (mode === 'dark' || mode === 'light') await deps.settings.update({ themeMode: mode })
        })
    )
}
