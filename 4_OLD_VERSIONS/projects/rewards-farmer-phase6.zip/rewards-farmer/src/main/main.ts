import { app, BrowserWindow, dialog } from 'electron'
import { join } from 'node:path'
import { APP_NAME } from '../shared/app-info'
import { IPC } from '../shared/ipc-types'
import { AppSettingsStore } from './appSettings'
import { Redactor } from './engine/redact'
import { EngineSupervisor } from './engine/supervisor'
import { FarmerService } from './farmer'
import { registerIpc } from './ipc'
import { JsonlLog } from './jsonlLog'
import { createMainWindow } from './window'

app.setName(APP_NAME)

// Single instance lock (docs/architecture.md section 4, step 1).
if (!app.requestSingleInstanceLock()) {
    app.quit()
} else {
    let main: BrowserWindow | null = null
    let quitting = false

    const userData = app.getPath('userData')
    const logsDir = join(userData, 'logs')
    const redactor = new Redactor()
    const redact = (text: string) => redactor.redact(text)
    const appLog = new JsonlLog(logsDir, 'app.log', 'app', redact)
    const audit = new JsonlLog(logsDir, 'audit.log', 'audit', redact)
    const settings = new AppSettingsStore(userData)
    // Development: <project>/engine. Packaged builds (Phase 14) will ship it under resources/engine.
    const engineRoot = app.isPackaged
        ? join(process.resourcesPath, 'engine')
        : join(app.getAppPath(), 'engine')

    const supervisor = new EngineSupervisor({
        engineRoot,
        redact,
        pidFile: join(userData, 'engine.pid'),
        log: (level, message) => appLog.write({ level, component: 'EngineSupervisor', message }),
        shutdownGraceMs: 20000 // engine waits up to 15 s for its bot to stop
    })

    const farmer = new FarmerService({
        engineRoot,
        settings,
        supervisor,
        audit,
        appLog,
        redactor,
        pickAccountsFile: async () => {
            const options = {
                title: 'Choose your accounts file (.env)',
                properties: ['openFile' as const],
                filters: [
                    { name: 'Accounts file (.env)', extensions: ['env'] },
                    { name: 'All files', extensions: ['*'] }
                ]
            }
            const result =
                main !== null
                    ? await dialog.showOpenDialog(main, options)
                    : await dialog.showOpenDialog(options)
            return result.canceled || result.filePaths[0] === undefined ? null : result.filePaths[0]
        }
    })

    farmer.onChange((state) => {
        if (main !== null && !main.isDestroyed()) main.webContents.send(IPC.farmerStateChanged, state)
    })

    app.on('second-instance', () => {
        if (main === null) return
        if (main.isMinimized()) main.restore()
        main.focus()
    })

    // Never leave an orphan engine or bot behind (docs/architecture.md section 4 step 7, threat model T8).
    app.on('before-quit', (event) => {
        if (quitting) return
        quitting = true
        event.preventDefault()
        void farmer
            .dispose()
            .catch(() => undefined)
            .finally(() => app.quit())
    })

    void app.whenReady().then(async () => {
        registerIpc({ farmer, settings, getWindow: () => main })
        main = createMainWindow()
        main.on('closed', () => {
            main = null
        })
        app.on('activate', () => {
            if (BrowserWindow.getAllWindows().length === 0) main = createMainWindow()
        })
        appLog.write({ level: 'info', component: 'App', message: `started (engine root: ${engineRoot})` })
        await farmer.init()
    })

    app.on('window-all-closed', () => app.quit())
}
