import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { DEFAULT_SETTINGS, isValidTime } from '../shared/farmer-types'
import type { PersistedSettings } from '../shared/farmer-types'

// App preferences (docs/architecture.md section 3): `<userData>/app-settings.json`, versioned, atomic writes.
// Holds NO secrets. Only theme, the accounts file PATH, and the timer.

export interface LoadedSettings {
    readonly settings: PersistedSettings
    // Set when the file was unreadable/corrupt and defaults were used (the bad file is kept as a backup).
    readonly notice: string | null
}

export function sanitizeSettings(raw: unknown): PersistedSettings {
    const o = typeof raw === 'object' && raw !== null ? (raw as Record<string, unknown>) : {}
    return {
        schemaVersion: 1,
        themeMode: o['themeMode'] === 'light' ? 'light' : 'dark',
        accountsPath:
            typeof o['accountsPath'] === 'string' && o['accountsPath'] !== '' ? o['accountsPath'] : null,
        timerEnabled: o['timerEnabled'] === true,
        timerTime:
            typeof o['timerTime'] === 'string' && isValidTime(o['timerTime'])
                ? o['timerTime']
                : DEFAULT_SETTINGS.timerTime
    }
}

export class AppSettingsStore {
    private readonly file: string
    private current: PersistedSettings = DEFAULT_SETTINGS

    constructor(
        private readonly dir: string,
        private readonly now: () => number = Date.now
    ) {
        this.file = join(dir, 'app-settings.json')
    }

    get value(): PersistedSettings {
        return this.current
    }

    async load(): Promise<LoadedSettings> {
        let text: string
        try {
            text = await readFile(this.file, 'utf8')
        } catch (error) {
            if ((error as NodeJS.ErrnoException).code === 'ENOENT')
                return { settings: this.current, notice: null }
            return {
                settings: this.current,
                notice: 'The app settings file could not be read. Defaults are used.'
            }
        }
        try {
            this.current = sanitizeSettings(JSON.parse(text) as unknown)
            return { settings: this.current, notice: null }
        } catch {
            const backup = join(this.dir, `app-settings.corrupt-${String(this.now())}.json`)
            let kept = ''
            try {
                await rename(this.file, backup)
                kept = ' The unreadable file was kept as a backup next to it.'
            } catch {
                // keep going with defaults
            }
            return {
                settings: this.current,
                notice: `The app settings file was corrupt. Defaults are used.${kept}`
            }
        }
    }

    // Atomic: write a temp file, then rename over the real one (threat model T6).
    async update(patch: Partial<Omit<PersistedSettings, 'schemaVersion'>>): Promise<void> {
        const next = sanitizeSettings({ ...this.current, ...patch })
        await mkdir(this.dir, { recursive: true })
        const tmp = `${this.file}.tmp`
        await writeFile(tmp, `${JSON.stringify(next, null, 4)}\n`, 'utf8')
        await rename(tmp, this.file)
        this.current = next
    }
}
