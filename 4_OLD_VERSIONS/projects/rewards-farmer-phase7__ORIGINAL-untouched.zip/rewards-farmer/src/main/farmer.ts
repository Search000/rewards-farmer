import { randomUUID } from 'node:crypto'
import { copyFile, constants as fsConstants } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { isValidTime } from '../shared/farmer-types'
import type {
    ActionResult,
    ErrorCode,
    FarmerNotice,
    FarmerState,
    LastExit,
    PersistedSettings,
    RunPhase
} from '../shared/farmer-types'
import type { AppSettingsStore } from './appSettings'
import { AppError } from './engine/apiClient'
import type { EditOutcome } from './accounts'
import { loadAccountsFile } from './engine/envFile'
import type { ParsedAccountsFile } from './engine/envFile'
import type { Redactor } from './engine/redact'
import { buildHomeNumbers, latestActivity, parsePhase, statusLastExit } from './engine/snapshot'
import type { HomeNumbers } from './engine/snapshot'
import type { EngineSupervisor } from './engine/supervisor'
import { isProcessAlive, killTree } from './engine/supervisor'
import type { JsonlLog } from './jsonlLog'
import { Scheduler } from './scheduler'

// The Home / Farmer service (docs/architecture.md sections 2, 4, 7). Everything shown on the Home screen comes
// from here, and every number is real engine data or null. No renderer string is ever used as a file path.

export interface FarmerDeps {
    readonly engineRoot: string
    readonly settings: AppSettingsStore
    readonly supervisor: EngineSupervisor
    readonly audit: JsonlLog
    readonly appLog: JsonlLog
    readonly redactor: Redactor
    // Opens the OS file dialog (Electron `dialog` in production). Returns null when the user cancels.
    readonly pickAccountsFile: () => Promise<string | null>
    readonly pollIdleMs?: number
    readonly pollActiveMs?: number
    readonly schedulerTickMs?: number
    readonly now?: () => number
}

type Busy = 'starting' | 'stopping' | 'picking' | 'engine' | null
type Listener = (state: FarmerState) => void

const ACTIVE: readonly RunPhase[] = ['starting', 'running', 'stopping']

interface StartBlock {
    readonly code: ErrorCode
    readonly message: string
}

const EMPTY_NUMBERS: HomeNumbers = {
    account: null,
    points: null,
    proxy: null,
    all: null,
    finished: null,
    failed: null
}

export class FarmerService {
    private readonly listeners = new Set<Listener>()
    private readonly scheduler: Scheduler
    private settingsNotice: string | null = null
    private accountsFile: ParsedAccountsFile | null = null
    private accountsStatus: 'not-set' | 'ok' | 'error' = 'not-set'
    private accountsError: string | null = null
    private busy: Busy = null
    private phase: RunPhase = 'unknown'
    private startedAt: string | null = null
    private lastExit: LastExit | null = null
    private numbers: HomeNumbers = EMPTY_NUMBERS
    private section: string | null = null
    private detail: string | null = null
    private lastBotPid: number | null = null
    private stopRequested = false
    private runNotice: FarmerNotice | null = null
    private timerNotice: FarmerNotice | null = null
    private pollTimer: NodeJS.Timeout | null = null
    private refreshing = false
    private disposed = false
    private lastKey = ''

    constructor(private readonly deps: FarmerDeps) {
        this.scheduler = new Scheduler({
            now: deps.now ?? Date.now,
            tickMs: deps.schedulerTickMs ?? 1000,
            onFire: (info) => void this.onTimerFire(info.scheduledFor),
            onMissed: (info) => this.onTimerMissed(info.scheduledFor, info.lateByMs)
        })
        deps.supervisor.on('change', () => this.emit())
        deps.supervisor.on('unexpected-exit', () => this.onEngineCrashed())
    }

    // ---- lifecycle -----------------------------------------------------------------------------------------

    async init(): Promise<void> {
        const loaded = await this.deps.settings.load()
        this.settingsNotice = loaded.notice
        this.log('info', 'FarmerService', 'init')
        const s = loaded.settings
        if (s.accountsPath !== null) await this.applyAccountsPath(s.accountsPath, 'startup')
        this.scheduler.configure(s.timerEnabled, s.timerTime)
        this.schedulePoll()
        this.emit()
    }

    async dispose(): Promise<void> {
        this.disposed = true
        if (this.pollTimer !== null) clearTimeout(this.pollTimer)
        this.scheduler.dispose()
        this.audit('quit', 'info', 'ok', 'App is closing; engine is being stopped.')
        await this.deps.supervisor.stop()
        // The engine stops its own bot on /shutdown. If the bot is still alive (engine had to be killed), kill it too.
        if (this.lastBotPid !== null && isProcessAlive(this.lastBotPid)) {
            killTree(this.lastBotPid)
            this.audit(
                'quit',
                'warn',
                'killed-bot',
                'Bot process was still alive after engine shutdown and was killed.'
            )
        }
        await Promise.all([this.deps.audit.flush(), this.deps.appLog.flush()])
    }

    onChange(listener: Listener): () => void {
        this.listeners.add(listener)
        return () => this.listeners.delete(listener)
    }

    // ---- state -----------------------------------------------------------------------------------------------

    getState(): FarmerState {
        const sup = this.deps.supervisor.snapshot()
        const block = this.startBlock()
        return {
            engine: { link: sup.link, detail: sup.detail, version: sup.version },
            accounts: {
                path: this.deps.settings.value.accountsPath,
                status: this.accountsStatus,
                error: this.accountsError,
                count: this.accountsFile?.accountCount ?? null
            },
            run: { phase: this.phase, startedAt: this.startedAt, lastExit: this.lastExit },
            // "Current account" means the account being processed right now. When no run is active the honest value
            // is "none" (screenshot 1 shows "Current account: None" when idle), not the last account of an old run.
            current:
                this.phase === 'idle'
                    ? { account: null, points: null, section: null, detail: null, proxy: null }
                    : {
                          account: this.numbers.account,
                          points: this.numbers.points,
                          section: this.section,
                          detail: this.detail,
                          proxy: this.numbers.proxy
                      },
            summary: { all: this.numbers.all, finished: this.numbers.finished, failed: this.numbers.failed },
            timer: this.scheduler.state(),
            startDisabledReason: block === null ? null : block.message,
            stopDisabledReason: this.stopDisabledReason(),
            notices: this.buildNotices(),
            updatedAt: new Date().toISOString()
        }
    }

    private emit(): void {
        const state = this.getState()
        const { updatedAt: _ignored, ...rest } = state
        void _ignored
        const key = JSON.stringify(rest)
        if (key === this.lastKey) return
        this.lastKey = key
        for (const l of this.listeners) l(state)
    }

    private engineBuilt(): boolean {
        return existsSync(join(this.deps.engineRoot, 'dist', 'index.js'))
    }
    private engineExists(): boolean {
        return existsSync(join(this.deps.engineRoot, 'scripts', 'api', 'server.js'))
    }
    private configExists(): boolean {
        return existsSync(join(this.deps.engineRoot, 'config.json'))
    }

    // First reason that blocks Start, or null. Order matters: the user fixes the first thing first.
    private startBlock(): StartBlock | null {
        const link = this.deps.supervisor.snapshot().link
        if (this.busy === 'starting') return { code: 'RUN_ACTIVE', message: 'Starting...' }
        if (this.busy === 'stopping') return { code: 'RUN_ACTIVE', message: 'Stopping...' }
        if (this.busy === 'picking' || this.busy === 'engine')
            return { code: 'RUN_ACTIVE', message: 'Please wait, the engine is being prepared.' }
        if (this.accountsStatus === 'not-set')
            return { code: 'ACCOUNTS_NOT_SET', message: 'Choose an accounts file first (Open).' }
        if (this.accountsStatus === 'error')
            return {
                code: 'ACCOUNTS_INVALID',
                message: `Accounts file problem: ${this.accountsError ?? 'unknown'}`
            }
        if (!this.engineExists())
            return {
                code: 'ENGINE_MISSING',
                message: 'Engine folder not found. Run: git submodule update --init'
            }
        if (!this.engineBuilt())
            return {
                code: 'ENGINE_NOT_BUILT',
                message: 'Engine is not built. Run: npm run engine:install, then npm run engine:build'
            }
        if (!this.configExists())
            return {
                code: 'CONFIG_MISSING',
                message: 'Engine config.json is missing. Use "Create config" above.'
            }
        if (link !== 'ready') return { code: 'ENGINE_DOWN', message: `Engine API is not ready (${link}).` }
        if (this.phase === 'unknown')
            return { code: 'ENGINE_DOWN', message: 'Engine state unknown: the engine API is not reachable.' }
        if (ACTIVE.includes(this.phase))
            return { code: 'RUN_ACTIVE', message: `A run is already ${this.phase}.` }
        return null
    }

    private stopDisabledReason(): string | null {
        if (this.busy === 'stopping' || this.phase === 'stopping') return 'Already stopping...'
        if (this.phase === 'starting' || this.phase === 'running') return null
        if (this.phase === 'unknown') return 'Engine state unknown: the engine API is not reachable.'
        return 'No run in progress.'
    }

    private buildNotices(): FarmerNotice[] {
        const out: FarmerNotice[] = []
        const sup = this.deps.supervisor.snapshot()
        if (this.settingsNotice !== null)
            out.push({ id: 'settings', severity: 'warning', message: this.settingsNotice })
        if (this.accountsStatus === 'error' && this.accountsError !== null)
            out.push({ id: 'accounts', severity: 'error', message: `Accounts file: ${this.accountsError}` })
        if (!this.engineExists()) {
            out.push({
                id: 'engine-missing',
                severity: 'error',
                message: 'Engine folder not found. Run: git submodule update --init'
            })
        } else {
            if (!this.engineBuilt())
                out.push({
                    id: 'engine-not-built',
                    severity: 'warning',
                    message: 'Engine is not built yet. Run: npm run engine:install, then npm run engine:build'
                })
            if (!this.configExists())
                out.push({
                    id: 'config-missing',
                    severity: 'warning',
                    message: 'Engine config.json is missing.',
                    action: 'create-config'
                })
        }
        if (sup.link === 'failed' || sup.link === 'down')
            out.push({
                id: 'engine-link',
                severity: sup.link === 'failed' ? 'error' : 'warning',
                message: sup.detail ?? 'The engine API is not running.',
                ...(sup.link === 'failed' ? { action: 'restart-engine' as const } : {})
            })
        if (this.runNotice !== null) out.push(this.runNotice)
        if (this.timerNotice !== null) out.push(this.timerNotice)
        const logErr = this.deps.audit.lastError
        if (logErr !== null)
            out.push({
                id: 'audit-log',
                severity: 'warning',
                message: `The audit log cannot be written (${logErr}).`
            })
        return out
    }

    // ---- logging -----------------------------------------------------------------------------------------------

    private log(level: 'info' | 'warn' | 'error', component: string, message: string, corrId?: string): void {
        this.deps.appLog.write({ level, component, message, ...(corrId === undefined ? {} : { corrId }) })
    }

    private audit(
        action: string,
        level: 'info' | 'warn' | 'error',
        result: string,
        message: string,
        corrId?: string
    ): void {
        this.deps.audit.write({
            level,
            component: 'Farmer',
            action,
            result,
            message,
            ...(corrId === undefined ? {} : { corrId })
        })
    }

    private fail(action: string, corrId: string, code: ErrorCode, message: string): ActionResult {
        this.audit(action, 'warn', code, message, corrId)
        return { ok: false, code, message }
    }

    // ---- accounts file -----------------------------------------------------------------------------------------

    private async applyAccountsPath(
        path: string,
        source: 'pick' | 'startup',
        corrId = randomUUID()
    ): Promise<ActionResult> {
        const result = await loadAccountsFile(path)
        if (!result.ok) {
            if (source === 'startup') {
                // The saved file is gone or broken: keep the path visible so the user sees what is wrong.
                this.accountsFile = null
                this.accountsStatus = 'error'
                this.accountsError = result.message
            }
            return this.fail('accounts-file', corrId, 'ACCOUNTS_INVALID', result.message)
        }
        this.accountsFile = result.file
        this.accountsStatus = 'ok'
        this.accountsError = null
        for (const secret of result.file.secretValues) this.deps.redactor.add(secret)
        this.busy = 'engine'
        this.emit()
        try {
            const started = await this.deps.supervisor.start(result.file.vars)
            this.audit(
                'accounts-file',
                started.ok ? 'info' : 'error',
                started.ok ? 'ok' : (started.code ?? 'ENGINE_START_FAILED'),
                `Accounts file ready (${String(result.file.accountCount)} accounts). Engine ${started.ok ? 'started' : 'did not start'}.`,
                corrId
            )
            await this.refresh()
            return started.ok
                ? { ok: true, message: `${String(result.file.accountCount)} account(s) found.` }
                : started
        } finally {
            this.busy = null
            this.emit()
        }
    }

    async pickAccounts(): Promise<{ cancelled: boolean; result: ActionResult }> {
        const corrId = randomUUID()
        if (this.busy !== null || ACTIVE.includes(this.phase)) {
            return {
                cancelled: false,
                result: this.fail(
                    'pick-accounts',
                    corrId,
                    'RUN_ACTIVE',
                    'The accounts file cannot be changed while a run is active or the engine is busy.'
                )
            }
        }
        this.busy = 'picking'
        this.emit()
        let path: string | null
        try {
            path = await this.deps.pickAccountsFile()
        } finally {
            this.busy = null
        }
        if (path === null) {
            this.emit()
            return { cancelled: true, result: { ok: true, message: 'Cancelled.' } }
        }
        const result = await this.applyAccountsPath(path, 'pick', corrId)
        if (result.ok) {
            await this.deps.settings.update({ accountsPath: path }).catch((error: unknown) => {
                this.log(
                    'error',
                    'FarmerService',
                    `settings write failed: ${error instanceof Error ? error.message : String(error)}`
                )
            })
        }
        this.emit()
        return { cancelled: false, result }
    }

    // ---- accounts screen (Phase 7) -----------------------------------------------------------------------------

    accountsPath(): string | null {
        return this.deps.settings.value.accountsPath
    }

    // null = the accounts file may be edited now. A string = why not (shown on the disabled controls, rule 17).
    accountsEditBlock(): string | null {
        if (this.busy !== null) return 'The app is busy (engine starting or stopping). Try again in a moment.'
        if (ACTIVE.includes(this.phase))
            return 'A run is active. Stop it first: accounts cannot change during a run.'
        if (this.deps.settings.value.accountsPath === null) {
            return 'No accounts file chosen yet. Choose it on Home (Accounts Path / Open).'
        }
        return null
    }

    // Runs one accounts-file change while the app is marked busy, then restarts the engine on the changed file so the
    // engine never works with an old copy of the accounts. `work` does the file change and writes its own audit line.
    async editAccounts(work: (path: string) => Promise<EditOutcome>): Promise<ActionResult> {
        const corrId = randomUUID()
        const path = this.deps.settings.value.accountsPath
        const block = this.accountsEditBlock()
        if (block !== null || path === null) {
            return this.fail(
                'accounts-edit',
                corrId,
                path === null ? 'ACCOUNTS_NOT_SET' : 'RUN_ACTIVE',
                block ?? 'No accounts file chosen yet.'
            )
        }
        this.busy = 'engine'
        this.emit()
        try {
            const outcome = await work(path)
            if (!outcome.ok) return { ok: false, code: outcome.code, message: outcome.message }
            const reload = await this.reloadAccountsFile(path, corrId)
            return reload.ok
                ? outcome
                : {
                      ok: true,
                      message: `${outcome.message} The engine did not restart on the new file: ${reload.message}`
                  }
        } finally {
            this.busy = null
            this.emit()
        }
    }

    // Read the (just changed) accounts file again and restart the engine with it. When the file is no longer usable
    // (for example the last account was removed) the engine is stopped, so it cannot keep running with old accounts.
    private async reloadAccountsFile(path: string, corrId: string): Promise<ActionResult> {
        const result = await loadAccountsFile(path)
        if (!result.ok) {
            this.accountsFile = null
            this.accountsStatus = 'error'
            this.accountsError = result.message
            await this.deps.supervisor.stop()
            await this.refresh()
            return this.fail('accounts-file', corrId, 'ACCOUNTS_INVALID', result.message)
        }
        this.accountsFile = result.file
        this.accountsStatus = 'ok'
        this.accountsError = null
        for (const secret of result.file.secretValues) this.deps.redactor.add(secret)
        const started = await this.deps.supervisor.start(result.file.vars)
        this.audit(
            'accounts-file',
            started.ok ? 'info' : 'error',
            started.ok ? 'ok' : (started.code ?? 'ENGINE_START_FAILED'),
            `Accounts file reloaded after a change (${String(result.file.accountCount)} accounts). Engine ${started.ok ? 'restarted' : 'did not start'}.`,
            corrId
        )
        await this.refresh()
        return started
    }

    // ---- run control -------------------------------------------------------------------------------------------

    async startRun(source: 'user' | 'timer' = 'user'): Promise<ActionResult> {
        const corrId = randomUUID()
        const block = this.startBlock()
        if (block !== null) return this.fail('start', corrId, block.code, block.message)
        const api = this.deps.supervisor.api
        if (api === null) return this.fail('start', corrId, 'ENGINE_DOWN', 'The engine API is not ready.')

        this.busy = 'starting' // duplicate-start guard: a second click or the timer sees `busy` and is refused
        this.emit()
        try {
            await api.start({})
            this.stopRequested = false
            this.runNotice = null
            this.phase = 'starting'
            this.audit('start', 'info', 'ok', `Run requested (${source}). POST /start -> 202.`, corrId)
            this.log('info', 'FarmerService', `run requested (${source})`, corrId)
            await this.refresh()
            return { ok: true, message: 'Run started.' }
        } catch (error) {
            const app = toAppError(error)
            if (app.code === 'RUN_ACTIVE') await this.refresh() // engine says a run exists: show the truth
            return this.fail('start', corrId, app.code, app.message)
        } finally {
            this.busy = null
            this.emit()
        }
    }

    async stopRun(): Promise<ActionResult> {
        const corrId = randomUUID()
        const reason = this.stopDisabledReason()
        if (reason !== null)
            return this.fail('stop', corrId, this.phase === 'unknown' ? 'ENGINE_DOWN' : 'NOT_RUNNING', reason)
        const api = this.deps.supervisor.api
        if (api === null) return this.fail('stop', corrId, 'ENGINE_DOWN', 'The engine API is not ready.')
        this.busy = 'stopping'
        this.stopRequested = true
        this.emit()
        try {
            await api.stop()
            this.audit('stop', 'info', 'ok', 'Stop requested. POST /stop -> 202.', corrId)
            await this.refresh()
            return { ok: true, message: 'Stopping...' }
        } catch (error) {
            const app = toAppError(error)
            if (app.code !== 'NOT_RUNNING') this.stopRequested = false
            await this.refresh()
            return this.fail('stop', corrId, app.code, app.message)
        } finally {
            this.busy = null
            this.emit()
        }
    }

    async restartEngine(): Promise<ActionResult> {
        const corrId = randomUUID()
        if (ACTIVE.includes(this.phase) || this.busy !== null)
            return this.fail('restart-engine', corrId, 'RUN_ACTIVE', 'Stop the run first.')
        if (this.accountsFile === null)
            return this.fail(
                'restart-engine',
                corrId,
                'ACCOUNTS_NOT_SET',
                'Choose a valid accounts file first.'
            )
        this.busy = 'engine'
        this.emit()
        try {
            const res = await this.deps.supervisor.start(this.accountsFile.vars)
            this.audit(
                'restart-engine',
                res.ok ? 'info' : 'error',
                res.ok ? 'ok' : (res.code ?? 'ENGINE_START_FAILED'),
                res.message,
                corrId
            )
            await this.refresh()
            return res
        } finally {
            this.busy = null
            this.emit()
        }
    }

    // Copies config.example.json to config.json, ONLY if config.json does not exist (rule 10: never overwrite).
    async createConfig(): Promise<ActionResult> {
        const corrId = randomUUID()
        const target = join(this.deps.engineRoot, 'config.json')
        const source = join(this.deps.engineRoot, 'config.example.json')
        if (existsSync(target))
            return this.fail(
                'create-config',
                corrId,
                'BAD_REQUEST',
                'config.json already exists. It was not changed.'
            )
        try {
            await copyFile(source, target, fsConstants.COPYFILE_EXCL)
        } catch (error) {
            const code = (error as NodeJS.ErrnoException).code
            return this.fail(
                'create-config',
                corrId,
                'WRITE_FAILED',
                `Could not create config.json (${code ?? 'unknown error'}).`
            )
        }
        this.audit('create-config', 'info', 'ok', 'config.json created from config.example.json.', corrId)
        this.emit()
        return { ok: true, message: 'config.json created from the engine example.' }
    }

    // ---- timer -------------------------------------------------------------------------------------------------

    async setTimer(enabled: boolean, time: string): Promise<ActionResult> {
        const corrId = randomUUID()
        if (!isValidTime(time))
            return this.fail('set-timer', corrId, 'INVALID_TIME', 'Time must be HH:MM (24 hours).')
        try {
            await this.deps.settings.update({ timerEnabled: enabled, timerTime: time })
        } catch (error) {
            return this.fail(
                'set-timer',
                corrId,
                'WRITE_FAILED',
                `Could not save the timer (${error instanceof Error ? error.message : 'unknown error'}).`
            )
        }
        this.scheduler.configure(enabled, time)
        this.timerNotice = null
        this.audit('set-timer', 'info', 'ok', `Timer ${enabled ? 'on' : 'off'}, time ${time}.`, corrId)
        this.emit()
        return {
            ok: true,
            message: enabled ? `Timer on: starts every day at ${time} while this app is open.` : 'Timer off.'
        }
    }

    private async onTimerFire(scheduledFor: string): Promise<void> {
        this.audit('timer-fire', 'info', 'fired', `Timer fired (scheduled ${scheduledFor}).`)
        const res = await this.startRun('timer')
        if (!res.ok) {
            this.timerNotice = {
                id: 'timer',
                severity: 'warning',
                message: `The timer could not start a run: ${res.message}`
            }
            this.emit()
        } else {
            this.timerNotice = null
        }
    }

    private onTimerMissed(scheduledFor: string, lateByMs: number): void {
        const mins = Math.round(lateByMs / 60000)
        this.audit(
            'timer-missed',
            'warn',
            'missed',
            `Timer for ${scheduledFor} missed by ${String(mins)} min (PC asleep or app busy). Not started late.`
        )
        this.timerNotice = {
            id: 'timer',
            severity: 'warning',
            message: `The timer time passed ${String(mins)} minutes ago while the app was not running it. No run was started. The next start is tomorrow.`
        }
        this.emit()
    }

    // ---- polling -----------------------------------------------------------------------------------------------

    private schedulePoll(): void {
        if (this.disposed) return
        const delay = ACTIVE.includes(this.phase)
            ? (this.deps.pollActiveMs ?? 1000)
            : (this.deps.pollIdleMs ?? 5000)
        this.pollTimer = setTimeout(() => {
            void this.refresh().finally(() => this.schedulePoll())
        }, delay)
        this.pollTimer.unref()
    }

    // Pull fresh data from the engine. Public so tests and the UI "refresh" can force it.
    async refresh(): Promise<void> {
        if (this.refreshing) return
        this.refreshing = true
        const before = this.phase
        try {
            const api = this.deps.supervisor.api
            if (api === null) {
                this.phase = 'unknown'
                this.numbers = EMPTY_NUMBERS
                this.section = null
                this.detail = null
                return
            }
            try {
                const [status, points, accounts] = await Promise.all([
                    api.status(),
                    api.points(),
                    api.accounts()
                ])
                const history =
                    points.accounts !== undefined && points.accounts.length > 0
                        ? null
                        : await api.history().catch(() => null)
                this.phase = parsePhase(status.state)
                this.startedAt = typeof status.startedAt === 'string' ? status.startedAt : null
                this.lastExit = statusLastExit(status)
                if (typeof status.pid === 'number') this.lastBotPid = status.pid
                this.numbers = buildHomeNumbers({ points, accounts, history })
                if (this.phase === 'running') {
                    const logs = await api.logs(30).catch(() => null)
                    const act = latestActivity(logs, (s) => this.deps.redactor.redact(s))
                    this.section = act.section
                    this.detail = act.detail
                } else {
                    this.section = null
                    this.detail = null
                }
                if (this.phase === 'idle') this.lastBotPid = null
                if (ACTIVE.includes(before) && this.phase === 'idle') await this.onRunEnded(api)
            } catch {
                this.phase = 'unknown'
                this.numbers = EMPTY_NUMBERS
                this.section = null
                this.detail = null
            }
        } finally {
            this.refreshing = false
            this.emit()
        }
    }

    private async onRunEnded(api: NonNullable<EngineSupervisor['api']>): Promise<void> {
        const exit = this.lastExit
        const code = exit?.code ?? null
        if (this.stopRequested) {
            this.runNotice = { id: 'run', severity: 'info', message: 'Run stopped.' }
            this.audit('run-ended', 'info', 'stopped', 'Run stopped by request.')
        } else if (code === 0 && exit?.error === undefined) {
            this.runNotice = { id: 'run', severity: 'info', message: 'Run finished.' }
            this.audit('run-ended', 'info', 'finished', 'Run finished with exit code 0.')
        } else {
            const errors = await api.errors(5).catch(() => null)
            // Prefer the bot's own last error line over the API controller's generic "Run finished (code N)".
            const list = errors?.errors ?? []
            const lastErr = (list.filter((e) => e.source !== 'controller').at(-1) ?? list.at(-1))?.message
            const extra =
                typeof lastErr === 'string' && lastErr !== ''
                    ? ` Last engine error: ${this.deps.redactor.redact(lastErr)}`
                    : ''
            const how =
                exit?.error !== undefined
                    ? this.deps.redactor.redact(exit.error)
                    : exit?.signal != null
                      ? `signal ${exit.signal}`
                      : `exit code ${String(code)}`
            this.runNotice = {
                id: 'run',
                severity: 'error',
                message: `The run ended unexpectedly (${how}).${extra}`
            }
            this.audit('run-ended', 'error', 'unexpected-exit', `Run ended unexpectedly (${how}).${extra}`)
        }
        this.stopRequested = false
    }

    private onEngineCrashed(): void {
        const wasActive = ACTIVE.includes(this.phase)
        this.phase = 'unknown'
        this.numbers = EMPTY_NUMBERS
        this.section = null
        this.detail = null
        this.audit('engine-crash', 'error', 'api-exited', 'The engine API process exited unexpectedly.')
        // T8: the API died. A bot it started may still run with nobody controlling it. Stop it.
        if (this.lastBotPid !== null && isProcessAlive(this.lastBotPid)) {
            killTree(this.lastBotPid)
            this.audit(
                'engine-crash',
                'warn',
                'killed-bot',
                `Bot process ${String(this.lastBotPid)} was killed to avoid an orphan.`
            )
            this.runNotice = {
                id: 'run',
                severity: 'error',
                message:
                    'The engine API crashed during a run. The bot process was stopped. The run is incomplete.'
            }
        } else if (wasActive) {
            this.runNotice = {
                id: 'run',
                severity: 'error',
                message: 'The engine API stopped during a run. The run is incomplete.'
            }
        }
        this.lastBotPid = null
        this.stopRequested = false
        this.emit()
    }

    get settings(): PersistedSettings {
        return this.deps.settings.value
    }
}

function toAppError(error: unknown): AppError {
    return error instanceof AppError
        ? error
        : new AppError('ENGINE_ERROR', error instanceof Error ? error.message : 'Unknown error.')
}
