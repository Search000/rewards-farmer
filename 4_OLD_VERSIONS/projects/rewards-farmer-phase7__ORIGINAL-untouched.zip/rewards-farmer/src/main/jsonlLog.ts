import { appendFile, mkdir } from 'node:fs/promises'
import { join } from 'node:path'

// JSON Lines log writer (docs/architecture.md section 13). One object per line, redacted before it is written.
// A failing disk never crashes the app: the failure is remembered and shown in the UI (`lastError`).

export type LogLevel = 'info' | 'warn' | 'error'

export interface LogRecord {
    readonly level: LogLevel
    readonly component: string
    readonly message: string
    readonly action?: string
    readonly result?: string
    readonly corrId?: string
    readonly account?: string
}

// ISO-8601 with the local UTC offset (docs/architecture.md section 13: "UTC offset in every timestamp").
export function localIso(date: Date): string {
    const pad = (n: number, w = 2) => String(Math.abs(n)).padStart(w, '0')
    const off = -date.getTimezoneOffset()
    const sign = off >= 0 ? '+' : '-'
    return (
        `${String(date.getFullYear())}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}` +
        `T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}.${pad(date.getMilliseconds(), 3)}` +
        `${sign}${pad(Math.trunc(off / 60))}:${pad(off % 60)}`
    )
}

export class JsonlLog {
    private chain: Promise<void> = Promise.resolve()
    private failure: string | null = null
    private ready = false

    constructor(
        private readonly dir: string,
        private readonly file: string,
        private readonly source: 'app' | 'audit',
        private readonly redact: (text: string) => string,
        private readonly now: () => Date = () => new Date()
    ) {}

    get lastError(): string | null {
        return this.failure
    }

    write(record: LogRecord): void {
        const line = {
            ts: localIso(this.now()),
            level: record.level,
            source: this.source,
            component: record.component,
            ...(record.action === undefined ? {} : { action: record.action }),
            ...(record.result === undefined ? {} : { result: record.result }),
            ...(record.account === undefined ? {} : { account: record.account }),
            ...(record.corrId === undefined ? {} : { corrId: record.corrId }),
            message: this.redact(record.message)
        }
        const text = `${this.redact(JSON.stringify(line))}\n`
        this.chain = this.chain.then(async () => {
            try {
                if (!this.ready) {
                    await mkdir(this.dir, { recursive: true })
                    this.ready = true
                }
                await appendFile(join(this.dir, this.file), text, 'utf8')
                this.failure = null
            } catch (error) {
                this.failure = error instanceof Error ? error.message : String(error)
            }
        })
    }

    // Wait until everything queued so far is on disk (used on quit and in tests).
    flush(): Promise<void> {
        return this.chain
    }
}
