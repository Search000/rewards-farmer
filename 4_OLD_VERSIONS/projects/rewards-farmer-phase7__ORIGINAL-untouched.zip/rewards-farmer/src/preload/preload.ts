import { contextBridge, ipcRenderer } from 'electron'
import type { IpcRendererEvent } from 'electron'
import { ACCOUNTS_IPC } from '../shared/accounts-types'
import type { AccountInput, AccountsState } from '../shared/accounts-types'
import type { AppInfo } from '../shared/app-info'
import type { ActionResult, FarmerState, PersistedSettings, ThemeModeSetting } from '../shared/farmer-types'
import { IPC } from '../shared/ipc-types'
import type { FarmerShellApi, PickResult } from '../shared/ipc-types'

// The ONLY surface the renderer gets. Each method maps to one named channel; there is no passthrough.
const api: FarmerShellApi = {
    getAppInfo: () => ipcRenderer.invoke(IPC.appGetInfo) as Promise<AppInfo>,
    getFarmerState: () => ipcRenderer.invoke(IPC.farmerGetState) as Promise<FarmerState>,
    pickAccountsFile: () => ipcRenderer.invoke(IPC.farmerPickAccountsFile) as Promise<PickResult>,
    startRun: () => ipcRenderer.invoke(IPC.farmerStart) as Promise<ActionResult>,
    stopRun: () => ipcRenderer.invoke(IPC.farmerStop) as Promise<ActionResult>,
    createEngineConfig: () => ipcRenderer.invoke(IPC.farmerCreateConfig) as Promise<ActionResult>,
    restartEngine: () => ipcRenderer.invoke(IPC.farmerRestartEngine) as Promise<ActionResult>,
    setTimer: (enabled, time) =>
        ipcRenderer.invoke(IPC.farmerSetTimer, enabled, time) as Promise<ActionResult>,
    onFarmerState: (callback) => {
        const listener = (_event: IpcRendererEvent, state: FarmerState) => callback(state)
        ipcRenderer.on(IPC.farmerStateChanged, listener)
        return () => {
            ipcRenderer.removeListener(IPC.farmerStateChanged, listener)
        }
    },
    getAccountsState: () => ipcRenderer.invoke(ACCOUNTS_IPC.getState) as Promise<AccountsState>,
    addAccount: (input: AccountInput) => ipcRenderer.invoke(ACCOUNTS_IPC.add, input) as Promise<ActionResult>,
    updateAccount: (slot: number, expectedEmail: string, input: AccountInput) =>
        ipcRenderer.invoke(ACCOUNTS_IPC.update, slot, expectedEmail, input) as Promise<ActionResult>,
    removeAccount: (slot: number, expectedEmail: string) =>
        ipcRenderer.invoke(ACCOUNTS_IPC.remove, slot, expectedEmail) as Promise<ActionResult>,
    getSettings: () => ipcRenderer.invoke(IPC.settingsGet) as Promise<PersistedSettings>,
    setThemeMode: (mode: ThemeModeSetting) => ipcRenderer.invoke(IPC.settingsSetTheme, mode) as Promise<void>
}

contextBridge.exposeInMainWorld('farmerShell', api)
