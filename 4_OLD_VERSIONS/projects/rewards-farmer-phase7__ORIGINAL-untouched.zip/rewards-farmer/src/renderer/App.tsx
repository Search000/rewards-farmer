import CssBaseline from '@mui/material/CssBaseline'
import { ThemeProvider } from '@mui/material/styles'
import { useCallback, useEffect, useMemo, useState } from 'react'
import type { FarmerState } from '../shared/farmer-types'
import { AppShell } from './components/AppShell'
import type { EngineIndicator } from './components/AppBarShell'
import { NotificationProvider } from './components/Notifications'
import { useFarmerState } from './hooks/useFarmerState'
import { useHashRoute } from './hooks/useHashRoute'
import { AccountsPage } from './pages/AccountsPage'
import { DesignSystemPage } from './pages/DesignSystemPage'
import { HomePage } from './pages/HomePage'
import { PlaceholderPage } from './pages/PlaceholderPage'
import { buildTheme } from './theme'
import type { ThemeMode } from './tokens'

function engineIndicator(state: FarmerState | null): EngineIndicator | undefined {
    if (state === null) return undefined
    const v = state.engine.version === null ? '' : ` (v${state.engine.version})`
    switch (state.engine.link) {
        case 'ready':
            return { connected: true, label: `Engine: ready${v}` }
        case 'starting':
            return { connected: false, label: 'Engine: starting' }
        case 'down':
            return { connected: false, label: 'Engine: stopped or crashed' }
        case 'failed':
            return { connected: false, label: 'Engine: failed to start' }
        default:
            return { connected: false, label: 'Engine: not started' }
    }
}

export function App() {
    const [route, navigate] = useHashRoute()
    const farmer = useFarmerState()
    const [mode, setMode] = useState<ThemeMode>('dark')
    const theme = useMemo(() => buildTheme(mode), [mode])

    // The theme choice lives in the main-process settings file, so it survives a restart. Outside Electron it stays in memory.
    const api = farmer.api
    useEffect(() => {
        if (api === null) return
        void api.getSettings().then(
            (s) => setMode(s.themeMode),
            () => undefined // keep the default; the Home page reports real engine problems
        )
    }, [api])

    const toggleTheme = useCallback(() => {
        const next: ThemeMode = mode === 'dark' ? 'light' : 'dark'
        setMode(next)
        if (api !== null) void api.setThemeMode(next).catch(() => undefined)
    }, [mode, api])

    return (
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <NotificationProvider>
                <AppShell
                    engine={engineIndicator(farmer.state)}
                    route={route}
                    mode={mode}
                    onNavigate={navigate}
                    onToggleTheme={toggleTheme}
                >
                    {route === 'design-system' ? (
                        <DesignSystemPage />
                    ) : route === 'home' ? (
                        <HomePage farmer={farmer} />
                    ) : route === 'accounts' ? (
                        <AccountsPage farmer={farmer} />
                    ) : (
                        <PlaceholderPage route={route} />
                    )}
                </AppShell>
            </NotificationProvider>
        </ThemeProvider>
    )
}
