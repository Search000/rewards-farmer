import { defineConfig } from 'vitest/config'

export default defineConfig({
    test: {
        include: ['tests/**/*.test.{ts,tsx}'],
        environment: 'jsdom',
        setupFiles: ['tests/setup.ts'],
        css: false,
        // Main-process integration tests start a real engine API process; allow time for slow machines.
        testTimeout: 60000,
        hookTimeout: 60000
    }
})
